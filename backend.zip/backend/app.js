const express = require('express');
const app = express();

require('dotenv/config');

const api = process.env.API_URL;

app.get('/${api}/jobs', (req, res) =>{
    const job = {
        id: 1,
        name: 'hair dresser',
        from: 'Hadar Dimoll',
        to: 'Karney Shomron',
        image: 'some_url',
    }
    res.send(job);
})

app.post('${api}/jobs', (req, res) =>{
    const newJob = req.body;
    console.log(newJob);
    res.send(newJob);
})

app.listen(8000, ()=>{
    console.log('server is running http://localhost:8000');
})